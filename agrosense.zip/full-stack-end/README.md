# AgroSense - Smart Greenhouse Telemetry Dashboard

React + Vite + Tailwind CSS + React Router (front-end) | Node.js + Express (back-end) | PostgreSQL (database)

## Pages
- `/`          Home
- `/about`     About + team + contact info
- `/login`     Login / Register
- `/dashboard` Live dashboard (login required)

## Run
1. Put your PostgreSQL password in `backend/.env`
2. `npm run install-all`
3. `npm run setup`   (once)
4. `npm run dev`     (API + simulator + website together, runs for ever)
5. Open http://localhost:5173   login: admin / admin123
