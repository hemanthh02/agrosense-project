// server.js : starts the Express API on port 5000
require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/authRoutes');
const telemetryRoutes = require('./routes/telemetryRoutes');

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api', authRoutes);              // /api/register, /api/login
app.use('/api/telemetry', telemetryRoutes); // /api/telemetry

app.get('/', (req, res) => {
  res.send('AgroSense API is running');
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`AgroSense API running on http://localhost:${PORT}`);
});
