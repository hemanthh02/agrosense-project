-- schema.sql : creates the two tables used by AgroSense

CREATE TABLE IF NOT EXISTS users (
  userid VARCHAR(30) PRIMARY KEY,
  name   VARCHAR(100) NOT NULL,
  pwd    VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS telemetry (
  id            SERIAL PRIMARY KEY,
  temperature   REAL    NOT NULL,
  humidity      REAL    NOT NULL,
  soil_moisture REAL    NOT NULL,
  light         INTEGER NOT NULL,
  created_at    TIMESTAMP DEFAULT NOW()
);

-- live_status : always exactly 4 rows (one per sensor). The values are UPDATED
-- in place every 3 seconds, so this table is the easiest one to watch in pgAdmin.
CREATE TABLE IF NOT EXISTS live_status (
  parameter  VARCHAR(20) PRIMARY KEY,
  value      REAL NOT NULL,
  unit       VARCHAR(10),
  status     VARCHAR(10),
  updated_at TIMESTAMP DEFAULT NOW()
);
