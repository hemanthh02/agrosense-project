// simulator.js : pretends to be the ESP32.
// Every 3 seconds it sends new random readings to the API. It never stops.
require('dotenv').config();

const URL = `http://localhost:${process.env.PORT || 5000}/api/telemetry`;

// random number between min and max with 1 decimal
function random(min, max) {
  return Number((Math.random() * (max - min) + min).toFixed(1));
}

async function sendReading() {
  const reading = {
    temperature: random(22, 38),      // °C
    humidity: random(50, 90),         // %
    soil_moisture: random(25, 70),    // %
    light: Math.round(random(300, 1000)), // lx
  };

  try {
    const res = await fetch(URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(reading),
    });

    if (res.ok) {
      const saved = await res.json();
      console.log(
        `#${saved.id}  Temp: ${reading.temperature}C  Hum: ${reading.humidity}%  ` +
          `Soil: ${reading.soil_moisture}%  Light: ${reading.light}lx`
      );
    } else {
      console.log('API rejected the reading, status', res.status);
    }
  } catch (err) {
    // server not started yet or stopped: do NOT quit, just try again next time
    console.log('Waiting for the API server...');
  }
}

console.log('Sensor simulator started. Sending a reading every 3 seconds.');
sendReading();
setInterval(sendReading, 3000);
