// setupDb.js : run ONCE with  npm run setup
// 1. creates the database (if missing)  2. creates tables  3. adds demo user admin
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');
const bcrypt = require('bcryptjs');

async function main() {
  // Step 1: connect to the default "postgres" database and create ours
  const admin = new Client({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: 'postgres',
  });
  await admin.connect();

  const found = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [process.env.DB_NAME]);
  if (found.rowCount === 0) {
    await admin.query(`CREATE DATABASE ${process.env.DB_NAME}`);
    console.log('Database created:', process.env.DB_NAME);
  } else {
    console.log('Database already exists:', process.env.DB_NAME);
  }
  await admin.end();

  // Step 2: connect to our database and run schema.sql
  const client = new Client({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
  });
  await client.connect();

  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await client.query(sql);
  console.log('Tables created: users, telemetry');

  // Step 3: demo user  (admin / admin123)
  const hash = await bcrypt.hash('admin123', 10);
  await client.query(
    'INSERT INTO users (userid, name, pwd) VALUES ($1, $2, $3) ON CONFLICT (userid) DO NOTHING',
    ['admin', 'Admin', hash]
  );
  console.log('Demo user ready -> userid: admin   password: admin123');

  await client.end();
  console.log('Setup finished successfully.');
}

main().catch((err) => {
  console.error('Setup failed:', err.message);
  process.exit(1);
});
