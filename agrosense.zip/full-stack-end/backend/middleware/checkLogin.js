// checkLogin.js : protects routes. Allows only requests that carry a valid JWT.
const jwt = require('jsonwebtoken');

function checkLogin(req, res, next) {
  // The token comes in the header:  Authorization: Bearer <token>
  const header = req.headers.authorization;

  if (!header) {
    return res.status(401).json({ message: 'Please login first' });
  }

  const token = header.split(' ')[1];

  try {
    const data = jwt.verify(token, process.env.JWT_SECRET);
    req.user = data; // userid and name
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

module.exports = checkLogin;
