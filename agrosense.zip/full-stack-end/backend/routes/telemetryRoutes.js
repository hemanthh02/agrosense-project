// telemetryRoutes.js : /api/telemetry (POST from sensor, GET for dashboard)
const express = require('express');
const pool = require('../db');
const checkLogin = require('../middleware/checkLogin');

const router = express.Router();

// To let the project run for ever, only the newest MAX_ROWS readings are kept.
// Older rows are deleted automatically so the table never grows without limit.
const MAX_ROWS = 1000;


// Saves the newest value of each sensor in live_status (insert the first time, update after that)
async function updateLiveStatus(temperature, humidity, soil_moisture, light) {
  let tempStatus = 'NORMAL';
  if (temperature > 35) tempStatus = 'HIGH';
  if (temperature < 18) tempStatus = 'LOW';

  const humStatus = humidity > 85 ? 'HIGH' : 'NORMAL';
  const soilStatus = soil_moisture < 30 ? 'LOW' : 'NORMAL';

  const rows = [
    ['temperature', temperature, 'C', tempStatus],
    ['humidity', humidity, '%', humStatus],
    ['soil_moisture', soil_moisture, '%', soilStatus],
    ['light', light, 'lx', 'NORMAL'],
  ];

  for (const row of rows) {
    await pool.query(
      `INSERT INTO live_status (parameter, value, unit, status, updated_at)
       VALUES ($1, $2, $3, $4, NOW())
       ON CONFLICT (parameter)
       DO UPDATE SET value = $2, status = $4, updated_at = NOW()`,
      row
    );
  }
}

// POST /api/telemetry  (called by simulator.js / ESP32, no login)
router.post('/', async (req, res) => {
  const { temperature, humidity, soil_moisture, light } = req.body;

  // all four values must be present
  if (
    temperature === undefined ||
    humidity === undefined ||
    soil_moisture === undefined ||
    light === undefined
  ) {
    return res.status(400).json({ message: 'temperature, humidity, soil_moisture and light are required' });
  }

  try {
    const result = await pool.query(
      `INSERT INTO telemetry (temperature, humidity, soil_moisture, light)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [temperature, humidity, soil_moisture, light]
    );

    // update the 4 rows of the live_status table (values change in place)
    await updateLiveStatus(temperature, humidity, soil_moisture, light);

    // delete the very old rows
    await pool.query('DELETE FROM telemetry WHERE id <= $1', [result.rows[0].id - MAX_ROWS]);

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// GET /api/telemetry  (login required) -> latest 20 readings, newest first
router.get('/', checkLogin, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM telemetry ORDER BY id DESC LIMIT 20');
    res.json(result.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
