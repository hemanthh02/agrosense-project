// authRoutes.js : /api/register and /api/login
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');

const router = express.Router();

// POST /api/register
router.post('/register', async (req, res) => {
  const { userid, name, password } = req.body;

  if (!userid || !name || !password) {
    return res.status(400).json({ message: 'User ID, name and password are required' });
  }

  try {
    // is the user id already used?
    const exists = await pool.query('SELECT userid FROM users WHERE userid = $1', [userid]);
    if (exists.rowCount > 0) {
      return res.status(409).json({ message: 'User ID already taken' });
    }

    // hash the password, then save
    const hash = await bcrypt.hash(password, 10);
    await pool.query('INSERT INTO users (userid, name, pwd) VALUES ($1, $2, $3)', [userid, name, hash]);

    res.status(201).json({ message: 'Registered successfully! Please login.' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// POST /api/login
router.post('/login', async (req, res) => {
  const { userid, password } = req.body;

  if (!userid || !password) {
    return res.status(400).json({ message: 'User ID and password are required' });
  }

  try {
    const result = await pool.query('SELECT * FROM users WHERE userid = $1', [userid]);

    // same message for wrong id and wrong password
    if (result.rowCount === 0) {
      return res.status(401).json({ message: 'Invalid user ID or password' });
    }

    const user = result.rows[0];
    const ok = await bcrypt.compare(password, user.pwd);
    if (!ok) {
      return res.status(401).json({ message: 'Invalid user ID or password' });
    }

    // token valid for 2 hours
    const token = jwt.sign({ userid: user.userid, name: user.name }, process.env.JWT_SECRET, {
      expiresIn: '2h',
    });

    res.json({ token, userid: user.userid, name: user.name });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
