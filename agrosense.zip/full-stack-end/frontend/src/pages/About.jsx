// About.jsx : project details, team and contact information

const technologies = [
  { layer: 'Front-end', tech: 'React 18, Vite, Tailwind CSS, Recharts, React Router' },
  { layer: 'Back-end', tech: 'Node.js, Express.js, bcryptjs, jsonwebtoken' },
  { layer: 'Database', tech: 'PostgreSQL (pg)' },
  { layer: 'Sensing', tech: 'Node.js simulator (ESP32 planned)' },
];

const team = [
  { id: '2520040086', name: 'Deekshith' },
  { id: '2520040036', name: 'Hemanth' },
  { id: '2520040099', name: 'Prajwal' },
];

// contact details
const EMAIL = 'hanumanthuhemanth@klh.edu.in';
const PHONE = '9177337766';

function About() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-green-800 text-center">About AgroSense</h1>

      {/* about the project */}
      <section className="bg-white rounded-xl shadow p-6 mt-8">
        <h2 className="text-xl font-semibold mb-2">The Project</h2>
        <p className="text-gray-700">
          AgroSense is a full-stack web dashboard for monitoring the climate inside a smart
          greenhouse in real time. It tracks temperature, humidity, soil moisture and light
          intensity, saves every reading in PostgreSQL, and warns the grower on screen as soon as a
          value leaves its safe range. Access is protected by login using bcrypt and JWT.
        </p>
        <p className="text-gray-700 mt-3">
          In this version a Node.js simulator acts as the ESP32 sensor device. Real sensors can be
          connected later without changing the API or the dashboard.
        </p>
      </section>

      {/* technologies */}
      <section className="bg-white rounded-xl shadow p-6 mt-6">
        <h2 className="text-xl font-semibold mb-3">Technologies Used</h2>
        <table className="w-full text-left text-sm">
          <tbody>
            {technologies.map((t) => (
              <tr key={t.layer} className="border-b last:border-0">
                <td className="py-2 font-semibold w-32">{t.layer}</td>
                <td className="py-2 text-gray-700">{t.tech}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {/* team */}
      <section className="bg-white rounded-xl shadow p-6 mt-6">
        <h2 className="text-xl font-semibold mb-1">Our Team (Team No. 1)</h2>
        <p className="text-sm text-gray-500 mb-4">
          Full Stack Web Development (FSWD) PBL, KLU Hyderabad
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {team.map((m) => (
            <div key={m.id} className="border rounded-lg p-4 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-green-600 text-white flex items-center justify-center text-xl font-bold">
                {m.name[0]}
              </div>
              <p className="font-semibold mt-2">{m.name}</p>
              <p className="text-sm text-gray-500">{m.id}</p>
            </div>
          ))}
        </div>
        <p className="text-sm text-gray-600 mt-4">
          Guide: <span className="font-semibold">Dr. Karumuri Sri Rama Murthy</span>, Asst.
          Professor, Department of ECE, KLU Hyderabad
        </p>
      </section>

      {/* contact info */}
      <section className="bg-white rounded-xl shadow p-6 mt-6 border-t-4 border-green-600">
        <h2 className="text-xl font-semibold mb-4">Contact Us</h2>

        <div className="flex items-center gap-3 mb-3">
          <span className="text-2xl">✉</span>
          <div>
            <p className="text-sm text-gray-500">Email</p>
            <a href={'mailto:' + EMAIL} className="text-green-700 font-semibold hover:underline break-all">
              {EMAIL}
            </a>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-2xl">📞</span>
          <div>
            <p className="text-sm text-gray-500">Phone</p>
            <a href={'tel:+91' + PHONE} className="text-green-700 font-semibold hover:underline">
              {PHONE}
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;
