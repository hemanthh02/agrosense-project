// Home.jsx : first page the visitor sees
import { Link } from 'react-router-dom';

// small lists kept at the top so the page below stays easy to read
const features = [
  { icon: '🌡', title: 'Temperature', text: 'Know the heat inside the greenhouse at every moment.' },
  { icon: '💧', title: 'Humidity', text: 'Avoid plant disease by keeping humidity in range.' },
  { icon: '🌿', title: 'Soil Moisture', text: 'Get a warning when the soil is too dry.' },
  { icon: '☀', title: 'Light', text: 'Track light intensity in lux throughout the day.' },
];

const steps = [
  { number: '1', title: 'Sensor sends data', text: 'A reading is sent every 3 seconds.' },
  { number: '2', title: 'API saves it', text: 'Express stores it in PostgreSQL.' },
  { number: '3', title: 'Dashboard asks', text: 'React fetches the latest data every 5 seconds.' },
  { number: '4', title: 'You see alerts', text: 'Cards, chart and red banners show the status.' },
];

function Home({ token }) {
  return (
    <div>
      {/* hero */}
      <section className="bg-gradient-to-b from-green-100 to-green-50 text-center px-4 py-16">
        <h1 className="text-4xl sm:text-5xl font-bold text-green-800">AgroSense</h1>
        <p className="text-xl text-green-700 mt-2">Smart Greenhouse Telemetry Dashboard</p>
        <p className="max-w-2xl mx-auto text-gray-600 mt-4">
          Monitor temperature, humidity, soil moisture and light in real time, get instant alerts
          when a value goes out of range, and keep a history of every reading.
        </p>

        <div className="mt-8 flex justify-center gap-3">
          {token ? (
            <Link to="/dashboard" className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-lg">
              Open Dashboard
            </Link>
          ) : (
            <Link to="/login" className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-lg">
              Login / Register
            </Link>
          )}
          <Link to="/about" className="bg-white border border-green-600 text-green-700 font-semibold px-6 py-3 rounded-lg hover:bg-green-50">
            About Project
          </Link>
        </div>
      </section>

      {/* four sensors */}
      <section className="max-w-5xl mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold text-center mb-6">What AgroSense monitors</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((f) => (
            <div key={f.title} className="bg-white rounded-xl shadow p-5 text-center">
              <div className="text-4xl">{f.icon}</div>
              <h3 className="font-semibold mt-2">{f.title}</h3>
              <p className="text-sm text-gray-600 mt-1">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* how it works */}
      <section className="max-w-5xl mx-auto px-4 pb-16">
        <h2 className="text-2xl font-bold text-center mb-6">How it works</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {steps.map((s) => (
            <div key={s.number} className="bg-white rounded-xl shadow p-5 border-t-4 border-green-500">
              <div className="w-8 h-8 rounded-full bg-green-600 text-white flex items-center justify-center font-bold">
                {s.number}
              </div>
              <h3 className="font-semibold mt-3">{s.title}</h3>
              <p className="text-sm text-gray-600 mt-1">{s.text}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Home;
