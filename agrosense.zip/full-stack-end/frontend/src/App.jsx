// App.jsx : keeps the login state and decides which page to show for each URL
import { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import Home from './pages/Home.jsx';
import About from './pages/About.jsx';
import Login from './components/Login.jsx';
import Dashboard from './components/Dashboard.jsx';

function App() {
  // read the saved login (if any) from localStorage so refresh keeps us logged in
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [name, setName] = useState(localStorage.getItem('name'));

  function handleLogin(data) {
    localStorage.setItem('token', data.token);
    localStorage.setItem('name', data.name);
    setToken(data.token);
    setName(data.name);
  }

  function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('name');
    setToken(null);
    setName(null);
  }

  return (
    <div className="min-h-screen flex flex-col bg-green-50">
      <Navbar token={token} name={name} onLogout={handleLogout} />

      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home token={token} />} />
          <Route path="/about" element={<About />} />

          {/* if already logged in, /login goes straight to the dashboard */}
          <Route
            path="/login"
            element={token ? <Navigate to="/dashboard" /> : <Login onLogin={handleLogin} />}
          />

          {/* dashboard is private: no token -> go to login */}
          <Route
            path="/dashboard"
            element={
              token ? (
                <Dashboard token={token} name={name} onLogout={handleLogout} />
              ) : (
                <Navigate to="/login" />
              )
            }
          />

          {/* any unknown address -> Home */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>

      <Footer />
    </div>
  );
}

export default App;
