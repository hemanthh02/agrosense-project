// Dashboard.jsx : main page. Asks the API for new readings every 5 seconds.
import { useState, useEffect } from 'react';
import SensorCard from './SensorCard.jsx';
import AlertBanner from './AlertBanner.jsx';
import TrendChart from './TrendChart.jsx';
import ReadingsTable from './ReadingsTable.jsx';

function Dashboard({ token, name, onLogout }) {
  const [readings, setReadings] = useState([]);
  const [error, setError] = useState('');

  async function loadReadings() {
    try {
      const res = await fetch('/api/telemetry', {
        headers: { Authorization: 'Bearer ' + token },
      });

      // token missing / expired -> go back to the login page
      if (res.status === 401) {
        onLogout();
        return;
      }

      const data = await res.json();
      setReadings(data);
      setError('');
    } catch (err) {
      setError('Could not connect to the server');
    }
  }

  useEffect(() => {
    loadReadings(); // first load
    const timer = setInterval(loadReadings, 5000); // then every 5 seconds
    return () => clearInterval(timer); // clean up when page closes
  }, []);

  const latest = readings[0]; // newest reading

  return (
    <div>
      <div className="max-w-5xl mx-auto p-6">
        <h1 className="text-2xl font-bold text-green-800 mb-4">Welcome, {name}</h1>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-800 rounded p-3 mb-3">{error}</div>
        )}

        {!latest && !error && (
          <p className="text-gray-600">No readings yet. Start the simulator: npm run simulate</p>
        )}

        {latest && (
          <>
            <AlertBanner reading={latest} />

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
              <SensorCard title="Temperature" value={latest.temperature} unit="°C" icon="🌡" color="border-red-500" />
              <SensorCard title="Humidity" value={latest.humidity} unit="%" icon="💧" color="border-blue-500" />
              <SensorCard title="Soil Moisture" value={latest.soil_moisture} unit="%" icon="🌿" color="border-green-500" />
              <SensorCard title="Light" value={latest.light} unit="lx" icon="☀" color="border-yellow-500" />
            </div>

            <TrendChart readings={readings} />
            <ReadingsTable readings={readings} />
          </>
        )}
      </div>
    </div>
  );
}

export default Dashboard;
