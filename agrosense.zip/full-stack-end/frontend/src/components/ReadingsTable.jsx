// ReadingsTable.jsx : table of the recent readings
function ReadingsTable({ readings }) {
  return (
    <div className="bg-white rounded-xl shadow p-5 mt-6 overflow-x-auto">
      <h2 className="text-lg font-semibold mb-3">Recent Readings</h2>
      <table className="w-full text-sm text-left">
        <thead>
          <tr className="border-b text-gray-600">
            <th className="py-2">ID</th>
            <th>Time</th>
            <th>Temp (°C)</th>
            <th>Humidity (%)</th>
            <th>Soil (%)</th>
            <th>Light (lx)</th>
          </tr>
        </thead>
        <tbody>
          {readings.map((r) => (
            <tr key={r.id} className="border-b hover:bg-gray-50">
              <td className="py-2">{r.id}</td>
              <td>{new Date(r.created_at).toLocaleTimeString()}</td>
              <td>{r.temperature}</td>
              <td>{r.humidity}</td>
              <td>{r.soil_moisture}</td>
              <td>{r.light}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ReadingsTable;
