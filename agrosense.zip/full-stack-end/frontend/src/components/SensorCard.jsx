// SensorCard.jsx : one small card showing a single value
function SensorCard({ title, value, unit, icon, color }) {
  return (
    <div className={'bg-white rounded-xl shadow p-5 border-t-4 ' + color}>
      <p className="text-gray-500 text-sm">
        {icon} {title}
      </p>
      <p className="text-3xl font-bold mt-2">
        {value}
        <span className="text-lg text-gray-500 ml-1">{unit}</span>
      </p>
    </div>
  );
}

export default SensorCard;
