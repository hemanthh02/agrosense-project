// Login.jsx : one form used for both Login and Register
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Login({ onLogin }) {
  const [isRegister, setIsRegister] = useState(false);
  const navigate = useNavigate();
  const [userid, setUserid] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [isError, setIsError] = useState(false);

  async function handleSubmit() {
    setMessage('');

    const url = isRegister ? '/api/register' : '/api/login';
    const body = isRegister ? { userid, name, password } : { userid, password };

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();

      if (!res.ok) {
        setIsError(true);
        setMessage(data.message);
        return;
      }

      if (isRegister) {
        // registered: go back to the login form
        setIsError(false);
        setMessage(data.message);
        setIsRegister(false);
        setPassword('');
      } else {
        onLogin(data);
        navigate('/dashboard'); // go to the dashboard page
      }
    } catch (err) {
      setIsError(true);
      setMessage('Could not connect to the server');
    }
  }

  return (
    <div className="min-h-[75vh] flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-sm rounded-xl shadow-lg p-8">
        <h1 className="text-3xl font-bold text-green-700 text-center">AgroSense</h1>
        <p className="text-gray-500 text-center mb-6">Smart Greenhouse Dashboard</p>

        <h2 className="text-xl font-semibold mb-4">{isRegister ? 'Register' : 'Login'}</h2>

        <label className="block text-sm text-gray-600 mb-1">User ID</label>
        <input
          className="w-full border rounded px-3 py-2 mb-3 focus:outline-none focus:ring-2 focus:ring-green-400"
          value={userid}
          onChange={(e) => setUserid(e.target.value)}
          placeholder="admin"
        />

        {isRegister && (
          <>
            <label className="block text-sm text-gray-600 mb-1">Name</label>
            <input
              className="w-full border rounded px-3 py-2 mb-3 focus:outline-none focus:ring-2 focus:ring-green-400"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
            />
          </>
        )}

        <label className="block text-sm text-gray-600 mb-1">Password</label>
        <input
          type="password"
          className="w-full border rounded px-3 py-2 mb-4 focus:outline-none focus:ring-2 focus:ring-green-400"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="admin123"
        />

        {message && (
          <p className={'text-sm mb-3 ' + (isError ? 'text-red-600' : 'text-green-600')}>{message}</p>
        )}

        <button
          onClick={handleSubmit}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 rounded"
        >
          {isRegister ? 'Register' : 'Login'}
        </button>

        <p className="text-sm text-gray-600 text-center mt-4">
          {isRegister ? 'Already have an account?' : "Don't have an account?"}{' '}
          <button
            className="text-green-700 underline"
            onClick={() => {
              setIsRegister(!isRegister);
              setMessage('');
            }}
          >
            {isRegister ? 'Login' : 'Register'}
          </button>
        </p>
      </div>
    </div>
  );
}

export default Login;
