// AlertBanner.jsx : checks the latest reading and shows green / red banners
function AlertBanner({ reading }) {
  const alerts = [];

  if (reading.temperature > 35) alerts.push('Temperature is too high!');
  if (reading.temperature < 18) alerts.push('Temperature is too low!');
  if (reading.humidity > 85) alerts.push('Humidity is too high!');
  if (reading.soil_moisture < 30) alerts.push('Soil is too dry - water the plants!');

  if (alerts.length === 0) {
    return (
      <div className="bg-green-100 border border-green-400 text-green-800 rounded p-3 mb-3">
        All values are normal
      </div>
    );
  }

  return (
    <div>
      {alerts.map((text) => (
        <div key={text} className="bg-red-100 border border-red-400 text-red-800 rounded p-3 mb-3">
          ⚠ {text}
        </div>
      ))}
    </div>
  );
}

export default AlertBanner;
