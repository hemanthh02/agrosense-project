// Navbar.jsx : top bar shown on every page
import { NavLink, Link, useNavigate } from 'react-router-dom';

function Navbar({ token, name, onLogout }) {
  const navigate = useNavigate();

  function handleLogoutClick() {
    onLogout();
    navigate('/');
  }

  // NavLink gives us "isActive" so the current page link can be highlighted
  function linkClass({ isActive }) {
    return 'px-3 py-1 rounded ' + (isActive ? 'bg-green-900' : 'hover:bg-green-600');
  }

  return (
    <nav className="bg-green-700 text-white px-6 py-4 flex flex-wrap items-center justify-between gap-3">
      <Link to="/" className="text-2xl font-bold">
        🌱 AgroSense
      </Link>

      <div className="flex flex-wrap items-center gap-2">
        <NavLink to="/" className={linkClass} end>
          Home
        </NavLink>
        <NavLink to="/about" className={linkClass}>
          About
        </NavLink>

        {token ? (
          <>
            <NavLink to="/dashboard" className={linkClass}>
              Dashboard
            </NavLink>
            <span className="hidden sm:inline ml-2 text-green-100">Hi, {name}</span>
            <button
              onClick={handleLogoutClick}
              className="bg-white text-green-700 px-3 py-1 rounded font-semibold ml-2"
            >
              Logout
            </button>
          </>
        ) : (
          <NavLink
            to="/login"
            className="bg-white text-green-700 px-3 py-1 rounded font-semibold ml-2"
          >
            Login
          </NavLink>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
