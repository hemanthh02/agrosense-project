// TrendChart.jsx : line chart of temperature and humidity
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

function TrendChart({ readings }) {
  // API gives newest first, the chart needs oldest first
  const data = [...readings].reverse().map((r) => ({
    time: new Date(r.created_at).toLocaleTimeString(),
    Temperature: r.temperature,
    Humidity: r.humidity,
  }));

  return (
    <div className="bg-white rounded-xl shadow p-5 mt-6">
      <h2 className="text-lg font-semibold mb-3">Temperature and Humidity Trend</h2>
      <div style={{ width: '100%', height: 300 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="Temperature" stroke="#ef4444" isAnimationActive={false} />
            <Line type="monotone" dataKey="Humidity" stroke="#3b82f6" isAnimationActive={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export default TrendChart;
