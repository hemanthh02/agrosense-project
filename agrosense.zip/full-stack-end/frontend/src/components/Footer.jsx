// Footer.jsx : bottom bar shown on every page
function Footer() {
  return (
    <footer className="bg-green-800 text-green-100 text-center text-sm py-4">
      <p>AgroSense - Smart Greenhouse Telemetry Dashboard</p>
      <p>Full Stack Web Development PBL | KLU Hyderabad | 2026 - 2027</p>
    </footer>
  );
}

export default Footer;
