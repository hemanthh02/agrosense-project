import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Every request that starts with /api is forwarded to the back-end on port 5000
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': 'http://localhost:5000',
    },
  },
});
